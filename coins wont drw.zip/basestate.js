var BaseState = function() 
{
}

BaseState.prototype.load = function() 
{
}

BaseState.prototype.unload = function() 
{
}

BaseState.prototype.update = function(dt) 
{
}

BaseState.prototype.draw = function() 
{
}