var GamewinState = function() 
{
	this.prototype = BaseState;
}

GamewinState.prototype.load = function() 
{
}

GamewinState.prototype.unload = function() 
{
}

GamewinState.prototype.update = function(deltaTime) 
{
}

GamewinState.prototype.draw = function() 
{
}